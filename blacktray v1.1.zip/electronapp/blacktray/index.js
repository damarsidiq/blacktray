const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow
const path = require('path')

// Specify flash path, supposing it is placed in the same directory with main.js.
let pluginName
switch (process.platform) {
  case 'win32':
    pluginName = 'pepflashplayer.dll'
    break
  case 'darwin':
    pluginName = 'PepperFlashPlayer.plugin'
    break
  case 'linux':
    pluginName = 'libpepflashplayer.so'
    break
}
app.commandLine.appendSwitch('ppapi-flash-path', path.join(__dirname, pluginName))

// Optional: Specify flash version, for example, v17.0.0.169
app.commandLine.appendSwitch('ppapi-flash-version', '27.0.0.187')


let win

const {ipcMain} = require('electron')
ipcMain.on('asynchronous-message', (event, arg) => {
    if(arg == 'quitbro'){
      win.destroy();
    }
    else{
      win.webContents.session.clearCache(function(){});
        event.sender.send('asynchronous-reply','clearcache');
    }
})

function draw() {
    win = new BrowserWindow({ icon:'/media/damarsidiq/pic/icons/blacktray.png',width: 1300, height: 700,frame:false, resizable: true,y:0,x:20,webPreferences: {
      plugins: true,webSecurity: false
    } });
    win.webContents.session.clearCache(function(){});
    win.setTitle('BlackTray');
    win.setMenuBarVisibility(false);
    //win.setMenu(null);
    //win.webContents.openDevTools();
    win.isMaximizable(true);
    win.isResizable(true);
    win.setAlwaysOnTop(false, "floating");
    win.loadURL('http://pxpedia/pxpedia/?app=blacktray&d[electronapp]=1');
    win.show();
}
app.on('ready', draw)
