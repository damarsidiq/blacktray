<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
    }
    public function renamefile($data){
        $response['nicename'] = '';
        $response['rename'] = false;
            
        $rename = @rename($data['url'],$data['newurl']);
        if($rename){
            $nicenamex  = explode(DIRECTORY_SEPARATOR,$data['newurl']);
            $nicename   = $nicenamex[count($nicenamex)-1];
            $nicenamexx = explode('.',$nicename);
            unset($nicenamexx[count($nicenamexx)-1]);
            
            $nicename = implode('.',$nicenamexx);
            
            
            $nicenamex2  = explode(DIRECTORY_SEPARATOR,$data['url']);
            $nicename2   = $nicenamex2[count($nicenamex2)-1];
            $nicenamexx2 = explode('.',$nicename2);
            unset($nicenamexx2[count($nicenamexx2)-1]);
            
            $nicename2 = implode('.',$nicenamexx2);
            
            
            $rename = $this->renamefilefromplaylist($data['url'],$data['newurl']);
            
            if(file_exists(App::getConfig('uploads').'lyrical/'.$nicename2.'.btyc')){
                @rename(App::getConfig('uploads').'lyrical/'.$nicename2.'.btyc',App::getConfig('uploads').'lyrical/'.$nicename.'.btyc');
            }
            
            $response['nicename'] = $nicename;
            $response['rename'] = $rename;
        }
        
            $this->setPagevar('response',$response);
            return 'ajax';
    }
    public function deletefile($data){
        $delete = unlink($data['url']);
        
        if($delete){
            $delete = $this->removefilefromplaylist($data['url']);
        }
        
        $this->setPagevar('response',$delete);
        return 'ajax';
    }
    public function renamefilefromplaylist($url,$new){
        $rep = true;
        $files = $this->controller('home')->getFiles(App::getConfig('uploads'));
        foreach($files as $fk=>$fv){
            if(App::getSessionVar('homep') && strpos($fv['name'],'xvxv') === false){
                continue;
            }
            $content = file_get_contents(App::getConfig('uploads').$fv['name']);
            if(strpos($content,$url) !== false){
                $rep = $this->modifyplaylist($content,$url,$new,$fv['name']);
            }
        }
        return $rep;
    }
    public function modifyplaylist($content,$url,$new,$play){
        $hand   = fopen(App::getConfig('uploads').$play,'wb');
        $itemsx = explode('<*edsep*>',$content);
        foreach($itemsx as $k=>$v){
            if($v === '')
                continue;
                
            if(strpos($v,$url) !==false){
                $itemsx[$k]=str_replace($url,$new,$v);
            }
        }
        $nc     = implode('<*edsep*>',$itemsx);
        $repl   = fputs($hand,$nc);
        return $repl;
    }
    public function removefilefromplaylist($url){
        $rep = true;
        $files = $this->controller('home')->getFiles(App::getConfig('uploads'));
        foreach($files as $fk=>$fv){
            if(App::getSessionVar('homep') && strpos($fv['name'],'xvxv') === false){
                continue;
            }
            $content = file_get_contents(App::getConfig('uploads').$fv['name']);
            if(strpos($content,$url) !== false){
                $rep = $this->cleanplaylist($content,$url,$fv['name']);
            }
        }
        return $rep;
    }
    public function cleanplaylist($content,$url,$play){
        $hand = fopen(App::getConfig('uploads').$play,'wb');
        
        $itemsx = explode('<*edsep*>',$content);
        $items = array();
        $key = 0;
        foreach($itemsx as $k=>$v){
            if($v === '')
                continue;
                
            if(strpos($v,$url) ===false){
                $items[$key]=$v;
                $key++;
            }
        }
        $nc = implode('<*edsep*>',$items);
        
        
        $repl = fputs($hand,$nc);
        return $repl;
    }
    
    public function uploadlecturestills($data){
        $filedescription = explode('|',$_POST['filedescriptor']);
        $filenamex = explode('.',$filedescription[1]);
        $ext = $filenamex[count($filenamex)-1];
        $filename = 'a.'.$ext;
        App::uploadChunks($_FILES['file'],'',$filename);
        $this->setPagevar('response',$data);
        return 'ajax';
    }
}
?>