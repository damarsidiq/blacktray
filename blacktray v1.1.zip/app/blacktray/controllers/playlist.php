<?php

Class Playlist extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function fixed($data){
        $files = $this->controller('home')->getFiles(App::getConfig('uploads'));
        $files = $this->controller('sortfile')->pageInit($files);
        $exed = '';
        $exedc = 0;
        foreach($files as $fk=>$fv){
            $ex = explode('<*edsep*>',file_get_contents($fv['path']));
            $exed = '';
            $exedc = 0;
            foreach($ex as $i=>$v){
                if($v=='' || strpos($v,'bonuselem')!==false){
                    continue;
                }
                $v = str_replace('<^lastplayedelem^>','',$v);
                if(!@is_file($v)){
                    $exedc++;
                    $exed .= '--'.@filetype($v).'-'.$v.'--<br/>';
                }
                else{
                    //$exed .= $v.'!!!!!!!<br/>';
                }
            }
            if($exedc){
                echo '#######'.$fv['nicename'].'#######<br/>'.$exed;
                echo '<br/>'.$exedc.'***********************************<br/><br/><br/>';
            }
            
        }
        return 'plain';
    }
    public function save($data){
        $urls = $data['urls'];
        $hand = fopen(App::getConfig('uploads').$data['name'].'.btp','w');
        fputs($hand,$urls);
        $this->setPagevar('response',true);
        return 'ajax';
    }
    public function thelist($data){
        $files = $this->controller('home')->getFiles(App::getConfig('uploads'));
        $files = $this->controller('sortfile')->pageInit($files);
        $this->setPagevar('response',$files);
        return 'ajax';
    }
    public function items($data){
        $ps = file_get_contents(App::getConfig('uploads').$data['name'].'.btp');
        $itemsx = explode('<*edsep*>',$ps);
        $items = array();
        $bonus = array();
        $lastplayed = array();
        $sortedbonus = array();
        $key = 0;
        $bonuskey = 0;
        $lastplayedkey = 0;
        foreach($itemsx as $k=>$v){
            if($v === '')
                continue;
                
            if(strpos($v,'<^bonuselem^>') !== false){
                $vx = explode('<^bonuselem^>',$v);
                $bonus[$bonuskey]['type']   = $vx[0];
                $bonus[$bonuskey]['val']    = $vx[1];
                $bonus[$bonuskey]['item']   = $vx[2];
                $bonuskey++;
            }
            elseif(strpos($v,'<^lastplayedelem^>') !== false){
                $vx = explode('<^lastplayedelem^>',$v);
                $lastplayed[$lastplayedkey]['item']   = $vx[0];
                $lastplayedkey++;
            }
            else{
                $items[$key]['name'] = $this->nicename($v);
                $items[$key]['path'] = $v;    
                $key++;
            }
        }
        
        if(count($bonus)){
            uasort($bonus,function($a,$b){
                $sortf = $b['val'] > $a['val'] ? -1 : ($b['val'] == $a['val'] ? 0 : 1);
                return $sortf;
            });
            
            $sortedbonus = array();
            foreach($bonus as $k=>$v){
                $sortedbonus[] = array('type'=>$v['type'],'val'=>$v['val'],'item'=>$v['item']);
            }
        }
        $response = array('items'=>$items,'bonuselems'=>$sortedbonus,'lastplayed'=>$lastplayed);
        $this->setPagevar('response',$response);
        return 'ajax';
    }
    public function nicename($v){
        $x = explode('/',$v);
        $nicename = $x[count($x)-1];
        $nicenamex  = explode('.',$nicename);
        unset($nicenamex[count($nicenamex)-1]);
        $nicename = implode('.',$nicenamex);
        return $nicename;
    }
    public function delete($data){
        $f = unlink(App::getConfig('uploads').$data['name'].'.btp');
        $this->setPagevar('response',$f);
        return 'ajax';
    }
}
	

?>