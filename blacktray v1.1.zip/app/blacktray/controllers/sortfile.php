<?php

Class Sortfile extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function pageInit($data,$view='home'){
        $records = $data;
        uasort($records,function($a,$b){
            $sortf = strtolower($a['nicename'])< strtolower($b['nicename']) ? -1 : (strtolower($a['nicename']) == strtolower($b['nicename']) ? 0 : 1);
            if($sortf!=0){
                return $sortf;
            }
        });
        
        $sorted = array();
        foreach($records as $k=>$v){
            $sorted[] = $v;
        }
        
        return $sorted;
    }
}
	

?>