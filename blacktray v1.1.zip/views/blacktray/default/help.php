<ul style="text-align:left;" id="keyshort">
<li><span class="shortitem">D </span><span class="helpitemsep"></span>toggles light dark/bright</li>
<li><span class="shortitem">Z </span><span class="helpitemsep"></span>no show mode. hides video display</li>
<li><span class="shortitem">o </span><span class="helpitemsep"></span>lock video/audio control to always show</li>
<li><span class="shortitem">CTRL + i </span><span class="helpitemsep"></span>get lyric on currently playing song/focused item</li>
<li><span class="shortitem">CTRL + X </span><span class="helpitemsep"></span> clear playlist</li>
<li><span class="shortitem">x </span><span class="helpitemsep"></span> remove a track from the playlist</li>
<li><span class="shortitem">> </span><span class="helpitemsep"></span> next track</li>
<li><span class="shortitem">< </span><span class="helpitemsep"></span> previous track</li>
<li><span class="shortitem">CTRL</span><span class="helpitemsep"></span> switch focus between browser and playlist</li>
<li><span class="shortitem">UP</span><span class="helpitemsep"></span> highlights next track in focused list</li>
<li><span class="shortitem">DOWN</span><span class="helpitemsep"></span> highlights previous track in focused list</li>
<li><span class="shortitem">L </span><span class="helpitemsep"></span> displays all playlist</li>
<li><span class="shortitem">P </span><span class="helpitemsep"></span> displays playlist's track if in fullscreen mode</li>
<li><span class="shortitem">F </span><span class="helpitemsep"></span> toggles fullscreen mode</li>
<li><span class="shortitem">+ </span><span class="helpitemsep"></span> increase volume</li>
<li><span class="shortitem">- </span><span class="helpitemsep"></span> decrease volume</li>
<li><span class="shortitem">W </span><span class="helpitemsep"></span> displays search input</li>
<li><span class="shortitem">S </span><span class="helpitemsep"></span> toggles shuffle mode</li>
<li><span class="shortitem">R </span><span class="helpitemsep"></span> toggles repeat mode</li>
<li><span class="shortitem">N </span><span class="helpitemsep"></span> displays dialog to save current playlist</li>
<li><span class="shortitem">escape  </span><span class="helpitemsep"></span> closes dialog boxes/search input</li>
<li><span class="shortitem">E </span><span class="helpitemsep"></span> rename current highlighted track/move file location</li>
<li><span class="shortitem">F2 </span><span class="helpitemsep"></span> switch browser to next category</li>
<li><span class="shortitem">enter</span><span class="helpitemsep"></span> play track if playlist is focused, add track to playlist if browser is focused, submit form if in input text</li>
</ul>