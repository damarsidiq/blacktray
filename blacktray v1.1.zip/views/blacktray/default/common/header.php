<!DOCTYPE html><html>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<head>
    <meta charset="UTF-8">
    <link rel="canonical" href="http://localhost/vine.etc">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="robots" content="all">
    <?php $velp->printheadsrc(); ?>
    <title></title>
    <script>
        <?php 
            if(App::getSessionVar('homep')){
                echo 'var homep=true;';
            }
            else{
                echo 'var homep=false;';
            }
        ?>
        var ismobile = <?php echo $pagevar['ismobile']; ?>;
    </script>
</head>
<body class="dark">
    <div id="messagebox" class="">
        <div id="messageboxtitle"></div>
        <div id="messageboxcontent">
            <div id="messageboxmsg"></div>
            <div class="table"><div class="tablecell"></div></div>
        </div>
        <div id="messageboxaction">
            
        </div>
    </div>

    <div id="exitlyric" class="">X</div>
    <div id="savelyric" class=""></div>    
    <div id="lyrical" class=""></div>
    