<div id="help">
<?php include_once 'help.php'; ?>
</div>
<div id="filemenu">
    <?php foreach($pagevar['itemtype'] as $k=>$v){ ?>
        <span class="<?php echo $v['default']; ?>"><?php echo $k; ?></span>
    <?php } ?>
    <div id="helpo">?</div>
    <div id="reload"><a href="javascript:void(0);"></a></div>
    <div id="search"><a href="javascript:void(0);"></a><input type="text" name="search" value="" id="thesearchinput"></div>
</div>
<div id="playlistlabel">
    <span id="playlistcount"><?php echo $pagevar['playlistcount']; ?> playlists</span>
    <span id="saveplaylist"></span>
    <span id="shuffleplaylist" class="off">off</span>
    <span id="repeatplaylist" class="all">all</span>
    <span id="clearplaylist"></span>
</div>
<div id="filelist" class="active hocuspocus">
    <ul id="browser">
<?php 
    foreach($pagevar['files'] as $K=>$V){
        if(strpos($V['path'],'.vtt') !==false){
?>
    
    <li class="subtitlefile">
        <div class="name"><?php echo $V['nicename']; ?></div>
        <div class="url"><?php echo $V['path']; ?></div>
    </li> 
        
<?php
    }
    else{
?>

    <li class="fileitem">
        <div class="name"><?php echo $V['nicename']; ?></div>
        <div class="url"><?php echo $V['path']; ?></div>
        <div class="getlyrical">i</div>
        <div class="renamefileitem">#</div>
        <div class="removefileitem">x</div>
        <div class="addtop">+</div>
    </li>
        
        <?php }} ?>
    </ul>
</div>
<div id="filesdescript"><?php echo $pagevar['filescount']; ?> files found</div>

<div id="playlisttitle" class="active">untitled</div>
<ul id="theplaylist" class="active"></ul>

<div id="viwdio" class="minimized">
    <ul id="menuplayer" class="minimized hovered">
       <li id="closeplayer" class="mplaya">X</li> 
       <li id="minimize" class="minimized mplaya"></li> 
       <li id="showplaylist" class="mplaya">&equiv;</li> 
       <li id="nextplay" class="mplaya">&rarr;</li>
       <li id="prevplay" class="mplaya">&larr;</li>
       <li id="bookmarkses" class="mplaya">&para;</li>
       <li id="addbookmarkses" class="mplaya">&radic;</li>
    </ul>
    <a href="" id="player"></a>
    <div id="contcont">
        <div id="video-controls" class="controls" data-state="hidden"><button id="playpause" type="button" data-state="play"></button><button id="stop" type="button" data-state="stop"></button>
            <div class="progress">
                <div id="vtime"><div id="vtimepos">30.53</div><div>/</div><div id="vtimedur">101.54</div></div>
                <div id="progress">
                    <div id="progressballtrack"></div>
                    <span id="progress-bar"></span>
                </div>
            </div>
            <button id="fs" type="button" data-state="go-fullscreen"></button>
            <button id="volinc" type="button" data-state="volup"></button>
            <button id="voldec" type="button" data-state="voldown"></button>
            <button id="mute" type="button" data-state="mute"></button>
        </div>
    </div>
</div>
<div id="playlistslist" class="modalbox">
    <span class="closemodal">X</span>
    <div class="row center borderbottom head">
        <label>Playlists</label>
    </div>
    <ul id="playlistsul" class="playlist heightfull"></ul>
</div>
<div id="seekandvolnotif" class="modalbox">
    <div class="message">
        
    </div>
</div>
<div id="saveplaylistdialog" class="modalbox">
    <span class="closemodal">X</span>
    <div class="row center borderbottom head">
        <label>Save Playlist</label>
    </div>
    <div class="row center">
        <input type="text" id="playname" value="name" name="name">
    </div>
    <div class="row center">
        <input type="button" value="save" id="saveplaylistsubmit">
    </div>
</div>
