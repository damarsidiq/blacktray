<?php foreach($pagevar['files'] as $K=>$V){ 

    if(strpos($V['path'],'.vtt') !==false){
?>
    
    <li class="subtitlefile">
        <div class="name"><?php echo $V['nicename']; ?></div>
        <div class="url"><?php echo $V['path']; ?></div>
    </li> 
        
<?php
    }
    else{
?>

    <li class="fileitem">
        <div class="name"><?php echo $V['nicename']; ?></div>
        <div class="url"><?php echo $V['path']; ?></div>
        <div class="renamefileitem">#</div>
        <div class="removefileitem">x</div>
        <div class="addtop">+</div>
    </li>

<?php }} ?>