    
</body>
<script type="text/javascript">
var mobile = <?php echo $pagevar['ismobile']; ?>;
</script>
<?php $velp->printfootsrc(); ?>
</html>