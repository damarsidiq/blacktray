var currentplaying      = false;
var previousplay        = false;
var multiplaynavflag    = false;
var audio               =  new Audio("");
var vaudio              = false;
var thelists            = [];
var playlistses         = [];
var currentplaylist     = '';
var shuffle             = false;
var shuffleround        = 0;
var repeatplaylist      = 'all';
var navigatefrombutton  = false;
var searchputdont       = false;
var movinglist          = false;
var movingitemposition  = 0;
var marked              = false;
var movingstartx        = 0;
var movetheliststartx   = 0;
var mediastarttime      = 0;
var mediatimeseek       = 5;
var mediatimeseekjump   = 25;
var mediavolume         = 0.5;
var mediatypeflag       = 0;
var containeroffocus    = false;
var focuseditem         = false;
var seekandvolmsg       = '';
var filterflag          = 0;
var rememberedfocused   = [];
var searchshortcut      = false;
var bonusitems          = [];
var lastplayeditem      = false;
var playlisttodelete    = false;
var markisd             = false;
var vaudioControls      = false;
var vaudioContainer     = false;
var fullscreen          = false;
var progress            = false;
var playpause           = false;
var stop                = false;
var mute                = false;
var volinc              = false;
var voldec              = false;


$(document).ready(
    function(){
        if(homep===true){
            var boxtitle = 'Security Check';
            var boxcontent = '<input type="text" value="" name="seccheck" id="seccheckpasswd">';
            var boxaction = '<span id="submitseccheck">Confirm</span>';
            
            dialogbox(boxtitle,boxcontent,boxaction);   
            $('#seccheckpasswd').focus();
            
            $('#seccheckpasswd').on('keyup',function(event){
                event.stopPropagation();
                
                confirmpasswordcheck();
            });
            
            $('#submitseccheck').on('click',function(event){
                event.stopPropagation();
                
                confirmpasswordcheck();
            });
            
            return;
        }
        
        pageinit();
    }
);
function dialogbox(title,content,actions){
    confirmbox = new messagebox();
    confirmbox.displayfunc(title,content,actions);
}
function confirmpasswordcheck(){
    var passcheck = $('#seccheckpasswd').val();
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'home',a:'securecheck',d:{pass:passcheck}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        if(msg.result == true){
            $('#messagebox').after(msg.pagecontent);
            $('#messagebox').removeClass('active');
            
            pageinit();
        }
    });
}
function pageinit(){
    	// Obtain handles to buttons and other elements
		playpause = document.getElementById('playpause');
		stop = document.getElementById('stop');
		mute = document.getElementById('mute');
		volinc = document.getElementById('volinc');
		voldec = document.getElementById('voldec');
		progress = document.getElementById('progress');
		fullscreen = document.getElementById('fs');
		vaudioContainer = document.getElementById('viwdio');
		vaudioControls = document.getElementById('video-controls');
		// Add events for all buttons			
		playpause.addEventListener('click', function(e) {
		    e.stopPropagation();
			if (vaudio.paused || vaudio.ended) vaudio.play();
			else vaudio.pause();
		});			
		// Listen for fullscreen change events (from other controls, e.g. right clicking on the vaudio itself)
		document.addEventListener('fullscreenchange', function(e) {
			setFullscreenData(!!(document.fullScreen || document.fullscreenElement));
		});
		document.addEventListener('webkitfullscreenchange', function() {
			setFullscreenData(!!document.webkitIsFullScreen);
		});
		document.addEventListener('mozfullscreenchange', function() {
			setFullscreenData(!!document.mozFullScreen);
		});
		document.addEventListener('msfullscreenchange', function() {
			setFullscreenData(!!document.msFullscreenElement);
		});
		// React to the user clicking within the progress bar
		$('.progress')[0].addEventListener('click', function(e) {
			var pos = (e.clientX  - ($('#progress').parent()[0].offsetLeft+$('#viwdio')[0].offsetLeft+$('#contcont')[0].offsetLeft)) / this.offsetWidth;
			vaudio.currentTime = pos * vaudio.duration;
			seekandvolmsg = Math.round(((vaudio.currentTime)/(vaudio.duration))*100)+'%';
            showseekvolnotif();
		});
		// The Media API has no 'stop()' function, so pause the vaudio and reset its time and the progress bar
		stop.addEventListener('click', function(e) {
		    e.stopPropagation();
			vaudio.pause();
			vaudio.currentTime = 0;
			progress.value = 0;
			// Update the play/pause button's 'data-state' which allows the correct button image to be set via CSS
			changeButtonState('playpause');
		});
		mute.addEventListener('click', function(e) {
		    e.stopPropagation();
			vaudio.muted = !vaudio.muted;
			changeButtonState('mute');
		});
		volinc.addEventListener('click', function(e) {
		    e.stopPropagation();
			alterVolume('+');
		});
		voldec.addEventListener('click', function(e) {
		    e.stopPropagation();
			alterVolume('-');
		});
		fullscreen.addEventListener('click', function(e) {
		    e.stopPropagation();
			handleFullscreen();
		});
			
        subfind.updatesubs();
        rememberedfocused = [false,false,false,false];
        filehandler();
        $.each($('#filemenu').children(),function(){
           thelists[thelists.length] = [];
           thelists[thelists.length-1].name = $(this).html();
           if($(this).attr('class') == 'active'){
               thelists[thelists.length-1].content = $('#browser').html();
           }
           else{
                thelists[thelists.length-1].content = '';
           }
        });
        
        $('#filesdescript').on('click',function(event){
            event.stopPropagation();
            if(isanelectronapp){
                ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
            }
        });
        
        $('body').delegate('video','focus',function(event){
            event.stopPropagation();
            $(this).blur();
        });
        $('#menuplayer').on('mouseout',function(event){
            if(typeof $(event.relatedTarget).attr('class') !== 'undefined' && ($(event.relatedTarget).attr('class').indexOf('mplaya') !== -1 || $(event.relatedTarget).attr('id') == 'menuplayer')){
                return;
            }
            $('#menuplayer').removeClass('mousein');
            if($('#menuplayer').attr('class').indexOf('minimized') === -1){
                setTimeout(function(){
                    if($('#menuplayer').attr('class').indexOf('minimized') === -1){
                        if($('#menuplayer').attr('class').indexOf('mousein') === -1)
                            $('#menuplayer').removeClass('hovered');
                    }
                },3000);
            }
        });
        $('#menuplayer').on('mouseover',function(event){
            $('#menuplayer').addClass('hovered');
            $('#menuplayer').addClass('mousein');
        });
        $('body').delegate('#playname','focus',function(event){
            event.stopPropagation();
            $(this).addClass('focused');
        }); 
        $('body').delegate('#playname','blur',function(event){
            event.stopPropagation();
            $(this).removeClass('focused');
            if($(this).val() === ''){
                $(this).val('name');
            }
        });  
        $('body').delegate('#playname','keydown',function(event){        
            if(event.which == 27){
                $('#saveplaylistdialog').removeClass('active');
                containeroffocus    = false;
                focuseditem         = false;
                focusbrowseritem();
                return;
            }
            
            if($(this).val() == $(this).attr('name')){
                $(this).val('');
                return;
            }
        });
        $('#playname').on('keyup',function(event){
            event.stopPropagation();
            if(event.which == 13){
                if($('#playname').val() == '' || $('#playname').val() == 'name'){
                    return;
                }
                currentplaylist = $('#playname').val();
                var playlistitems = [];
                $.each($('#theplaylist').children(),function(i,v){
                    playlistitems[playlistitems.length] = $(v).children('.url').html();
                });
                playlistses[playlistses.length] = [];
                playlistses[playlistses.length-1].name = $('#playname').val();
                playlistses[playlistses.length-1].items = playlistitems;
                playlistobj.save(playlistses.length-1);
                
                $('#saveplaylistsubmit').parent().parent().children('.row').eq(0).html('saving...');
                return;
            }
            if($(this).val() == ''){
                $(this).val('name');
            }
        });
        
        $('body').on('keydown',function(event){
            event.stopPropagation();
            if( (typeof $('#search').attr('class') !== 'undefined' && $('#search').attr('class').indexOf('active') !== -1)  || $('#messagebox').attr('class').indexOf('active') !== -1  ){
                return;
            }
            if($('#messagebox').attr('class').indexOf('active') !== -1){
               return; 
            }
            if(typeof $('#playname').attr('id') !== 'undefined'){
                if(typeof $('#playname').attr('class') !== 'undefined' && $('#playname').attr('class').indexOf('focus') !== -1){
                    return;
                }
            }
            switch(event.which){
                case 66:
                    event.preventDefault();
                    handleaddmarks();
                break;
                case 49:
                    if(!bonusitems.length){
                        return;
                    }
                    
                    var beenthere;
                    if($('.bonusitemsitem.beenthere').length){
                        beenthere = $('.bonusitemsitem.beenthere');
                        $('.bonusitemsitem.beenthere').removeClass('beenthere');
                        if(typeof $(beenthere).next().attr('class') !== 'undefined'){
                            beenthere = $(beenthere).next();
                        }
                        else{
                            beenthere = $('#bookmarkedpoints').children().eq(0);
                        }
                    }
                    else{
                        beenthere = $('#bookmarkedpoints').children().eq(0);
                    }
                    $(beenthere).addClass('beenthere');
                    markisd = ($(beenthere).children('.bonival').html());
                    switch(mediatypeflag){
                        case 1:
                            audio.currentTime = markisd;
                        break;
                        case 0:
                            vaudio.currentTime = markisd;
                        break;
                        default:
                        break;
                    }
                    showbookmarkpos($(beenthere).children('.boniname').html());
                break;
                case 50:
                    if(!bonusitems.length){
                        return;
                    }
                    var beenthere;
                    if($('.bonusitemsitem.beenthere').length){
                        beenthere = $('.bonusitemsitem.beenthere');
                    }
                    else{
                        beenthere = $('#bookmarkedpoints').children().eq($('#bookmarkedpoints').children().length-1);
                    }
                    markisd = ($(beenthere).children('.bonival').html());
                    switch(mediatypeflag){
                        case 1:
                            audio.currentTime = markisd;
                        break;
                        case 0:
                            vaudio.currentTime = markisd;
                        break;
                        default:
                        break;
                    }
                    showbookmarkpos($(beenthere).children('.boniname').html());
                break;
                case 192:
                    if(!bonusitems.length){
                        return;
                    }
                    
                    var beenthere;
                    if($('.bonusitemsitem.beenthere').length){
                        beenthere = $('.bonusitemsitem.beenthere');
                        $('.bonusitemsitem.beenthere').removeClass('beenthere');
                        if(typeof $(beenthere).prev().attr('class') !== 'undefined'){
                            beenthere = $(beenthere).prev();
                        }
                        else{
                            beenthere = $(beenthere).parent().children().eq($('#bookmarkedpoints').children().length-1);
                        }
                    }
                    else{
                        beenthere = $('#bookmarkedpoints').children().eq($('#bookmarkedpoints').children().length-1);
                    }
                    $(beenthere).addClass('beenthere');
                    markisd = ($(beenthere).children('.bonival').html());
                    switch(mediatypeflag){
                        case 1:
                            audio.currentTime = markisd;
                        break;
                        case 0:
                            vaudio.currentTime = markisd;
                        break;
                        default:
                        break;
                    }
                    showbookmarkpos($(beenthere).children('.boniname').html());
                break;
                case 88:
                    if(containeroffocus == 2 && focuseditem !== false){
                        var tfocuseditem = focuseditem;
                        navlistitem(0);
                        
                        $(tfocuseditem).remove();
                        $('#playlisttitle').addClass('unsaved');
                    }
                break;
                case 27:
                    if($('#saveplaylistdialog').attr('class').indexOf('active') !== -1){
                        $('#saveplaylistdialog').removeClass('active');
                        focusbrowseritem();
                        return;
                    }
                    if($('#playlistslist').attr('class').indexOf('active') !== -1){
                        $('#playlistslist').removeClass('active');
                        containeroffocus    = false;
                        focuseditem         = false;
                        focusbrowseritem();
                    }
                break;
                case 113:
                    var spanitem = $('#filemenu').children('.active');
                    if(typeof $(spanitem).next().attr('class') !== 'undefined'){
                        spanitem = $(spanitem).next();
                    }
                    else{
                        spanitem = $('#filemenu').children().eq(0);
                    }
                    rememberedfocused[1] = false;
                    if(containeroffocus == 1 && focuseditem !== false){
                        focuseditem = false;
                    }
                    loadmenu(spanitem);
                break;
                case 78:
                    event.preventDefault();
                    showsaveplaylistdialog();
                break;
                case 76:
                    if(containeroffocus !== 0)
                        showplaylistlist();
                break;
                case 13:
                    enteritem();
                break;
                case 38:
                    event.preventDefault();
                    if(focuseditem !== false){
                        navlistitem(0);
                    }
                break;
                case 40:
                    event.preventDefault();
                    if(focuseditem !== false){
                        navlistitem(1);
                    }
                break;
                case 17:
                    switchcontaineroffocus();
                break;
                case 87:
                    showsearchform();
                    $('#thesearchinput').val('');
                break;
                case 81:
                    closetheplay();
                break;
                case 34:
                    switch(mediatypeflag){
                        case 1:
                            mediastarttime = audio.currentTime+mediatimeseekjump;
                            if(mediastarttime < audio.duration){
                                audio.currentTime = (mediastarttime);  
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(audio.duration))*100)+'%';
                        break;
                        case 0:
                            mediastarttime = vaudio.currentTime+mediatimeseekjump;
                            if(mediastarttime < vaudio.duration){
                                vaudio.currentTime = (mediastarttime);    
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(vaudio.duration))*100)+'%';
                        break;
                        default:
                        break;
                    }
                    showseekvolnotif();
                break;
                case 39:
                    switch(mediatypeflag){
                        case 1:
                            mediastarttime = audio.currentTime+mediatimeseek;
                            if(mediastarttime < audio.duration){
                                audio.currentTime = (mediastarttime);  
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(audio.duration))*100)+'%';
                        break;
                        case 0:
                            mediastarttime = vaudio.currentTime+mediatimeseek;
                            if(mediastarttime < vaudio.duration){
                                vaudio.currentTime = (mediastarttime);
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(vaudio.duration))*100)+'%';
                        break;
                        default:
                        break;
                    }
                    showseekvolnotif();
                break;
                case 33:
                    switch(mediatypeflag){
                        case 1:
                            mediastarttime = audio.currentTime-mediatimeseekjump;
                            if(mediastarttime > 0){
                                audio.currentTime = (mediastarttime);
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(audio.duration))*100)+'%';
                        break;
                        case 0:
                            mediastarttime = vaudio.currentTime-mediatimeseekjump;
                            if(mediastarttime > 0){
                                vaudio.currentTime = (mediastarttime);
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(vaudio.duration))*100)+'%';
                        break;
                        default:
                        break;
                    }
                    showseekvolnotif();
                break;
                case 37:
                    switch(mediatypeflag){
                        case 1:
                            mediastarttime = audio.currentTime-mediatimeseek;
                            if(mediastarttime > 0){
                                audio.currentTime = (mediastarttime);
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(audio.duration))*100)+'%';
                        break;
                        case 0:
                            mediastarttime = vaudio.currentTime-mediatimeseek;
                            if(mediastarttime > 0){
                                vaudio.currentTime = (mediastarttime);
                            }
                            seekandvolmsg = Math.round(((mediastarttime)/(vaudio.duration))*100)+'%';
                        break;
                        default:
                        break;
                    }
                    showseekvolnotif();
                break;
                case 82:
                    togglerepeat($('#repeatplaylist'));
                break;
                case 83:
                    toggleshuffle($('#shuffleplaylist'));
                break;
                case 70:
                    togglefullscreen($('#minimize'));
                break;
                case 80:
                    toggleplaylist();
                break;
                case 190:
                    playnext();
                break;
                case 188:
                    playprev();
                break;
                case 107:
                    mediavolume += 0.01;
                    if(mediavolume > 1){
                        mediavolume = 1;
                    }
                    switch(mediatypeflag){
                        case 1:
                            audio.volume = mediavolume;
                        break;
                        case 0:
                            vaudio.volume = mediavolume;
                        break;
                        default:
                        break;
                    }
                    seekandvolmsg = Math.round(mediavolume*100)+'%';
                    showseekvolnotif();
                break;
                case 109:
                    mediavolume -= 0.01;
                    if(mediavolume < 0){
                        mediavolume = 0;
                    }
                    switch(mediatypeflag){
                        case 1:
                            audio.volume = mediavolume;
                        break;
                        case 0:
                            vaudio.volume = mediavolume;
                        break;
                        default:
                        break;
                    }
                    seekandvolmsg = Math.round(mediavolume*100)+'%';
                    showseekvolnotif();
                break;
                case 32:
                    event.stopPropagation();
                    switch(mediatypeflag){
                        case 1:
                            if(audio.paused)
                                audio.play();
                            else
                                audio.pause();
                        break;
                        case 0:
                            if(vaudio.paused)
                                vaudio.play();
                            else
                                vaudio.pause();
                        break;
                        default:
                        break;
                    }
                break;
            }
        });
        
        $('body').delegate('.downloaditem','click',function(event){
            event.stopPropagation();
            var url = $(this).parent().children('.url')[0].innerText;
            window.open(url);
        });
        
        
        $('body').delegate('#shuffleplaylist','click',function(event){
            event.stopPropagation();
            toggleshuffle(this);
        }); 
    
        $('body').delegate('#repeatplaylist','click',function(event){
            event.stopPropagation();
            togglerepeat(this);
        }); 
        
        $('body').delegate('#filemenu span','click',function(){
            loadmenu(this);
        });
}
// Check the volume
var checkVolume = function(dir) {
	if (dir) {
		if (dir === '+') {
			mediavolume += 0.01;
            if(mediavolume > 1){
                mediavolume = 1;
            }
            switch(mediatypeflag){
                case 1:
                    audio.volume = mediavolume;
                break;
                case 0:
                    vaudio.volume = mediavolume;
                break;
                default:
                break;
            }
            seekandvolmsg = Math.round(mediavolume*100)+'%';
            showseekvolnotif();
		}
		else if (dir === '-') {
			mediavolume -= 0.01;
            if(mediavolume < 0){
                mediavolume = 0;
            }
            switch(mediatypeflag){
                case 1:
                    audio.volume = mediavolume;
                break;
                case 0:
                    vaudio.volume = mediavolume;
                break;
                default:
                break;
            }
            seekandvolmsg = Math.round(mediavolume*100)+'%';
            showseekvolnotif();
		}
		if (mediavolume <= 0) vaudio.muted = true;
		else vaudio.muted = false;
	}
	changeButtonState('mute');
}

// Change the volume
var alterVolume = function(dir) {
	checkVolume(dir);
}
// Changes the button state of certain button's so the correct visuals can be displayed with CSS
var changeButtonState = function(type) {
	// Play/Pause button
	if (type == 'playpause') {
		if (vaudio.paused || vaudio.ended) {
			playpause.setAttribute('data-state', 'play');
		}
		else {
			playpause.setAttribute('data-state', 'pause');
		}
	}
	// Mute button
	else if (type == 'mute') {
		mute.setAttribute('data-state', vaudio.muted ? 'unmute' : 'mute');
	}
}
// Set the vaudio container's fullscreen state
var setFullscreenData = function(state) {
	vaudioContainer.setAttribute('data-fullscreen', !!state);
	// Set the fullscreen button's 'data-state' which allows the correct button image to be set via CSS
	fullscreen.setAttribute('data-state', !!state ? 'cancel-fullscreen' : 'go-fullscreen');
}
// Checks if the document is currently in fullscreen mode
var isFullScreen = function() {
	return !!(document.fullScreen || document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement);
}
// Fullscreen
var handleFullscreen = function() {
	// If fullscreen mode is active...	
	if (isFullScreen()) {
		// ...exit fullscreen mode
		// (Note: this can only be called on document)
		if (document.exitFullscreen) document.exitFullscreen();
		else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
		else if (document.webkitCancelFullScreen) document.webkitCancelFullScreen();
		else if (document.msExitFullscreen) document.msExitFullscreen();
		setFullscreenData(false);
	}
	else {
		// ...otherwise enter fullscreen mode
		// (Note: can be called on document, but here the specific element is used as it will also ensure that the element's children, e.g. the custom controls, go fullscreen also)
		if (vaudioContainer.requestFullscreen) vaudioContainer.requestFullscreen();
		else if (vaudioContainer.mozRequestFullScreen) vaudioContainer.mozRequestFullScreen();
		else if (vaudioContainer.webkitRequestFullScreen) {
			// Safari 5.1 only allows proper fullscreen on the vaudio element. This also works fine on other WebKit browsers as the following CSS (set in styles.css) hides the default controls that appear again, and 
			// ensures that our custom controls are visible:
			// figure[data-fullscreen=true] vaudio::-webkit-media-controls { display:none !important; }
			// figure[data-fullscreen=true] .controls { z-index:2147483647; }
			vaudio.webkitRequestFullScreen();
		}
		else if (vaudioContainer.msRequestFullscreen) vaudioContainer.msRequestFullscreen();
		setFullscreenData(true);
	}
}
function focusbrowseritem(){
    if(rememberedfocused[1] !== false && $(rememberedfocused[1]).attr('class').indexOf('hide') === -1 ){
        focuseditem = rememberedfocused[1];
        $(focuseditem).addClass('focus');
    }
    else{
        for(var i=0;i<$('#browser').children().length;i++){
            if($('#browser').children().eq(i).attr('class').indexOf('hide') === -1){
                $('#browser').children().eq(i).addClass('focus');
                focuseditem = $('#browser').children('.focus');
                break;
            }
        }   
    }
    $(focuseditem)[0].scrollIntoView();
    filedescripttotal();
}

function filedescripttotal(){
    var filteredcount = 0;
    $.each($('#browser').children(),function(i,el){
        if($(el).attr('class').indexOf('hide') === -1){
            filteredcount++;
        }
    });
    $('#filesdescript').html(filteredcount+' files found');
}

function navlistitem(direction){
    $(focuseditem).removeClass('focus');
    switch(containeroffocus){
        case 1:
            switch(direction){
                case 0:
                    while(typeof $(focuseditem).prev().attr('class') !== 'undefined' && ($(focuseditem).prev().attr('class').indexOf('hide') !== -1 || $(focuseditem).prev().attr('class').indexOf('subtitlefile') !==-1)){
                        focuseditem = $(focuseditem).prev();
                    }  
                    if(typeof $(focuseditem).prev().attr('class') === 'undefined'){
                        focuseditem = $('#browser').children().eq($('#browser').children().length -1);
                        if($(focuseditem).attr('class').indexOf('hide') !== -1){
                            navlistitem(0);
                            return;
                        }
                    }
                    else
                        focuseditem = $(focuseditem).prev();
                break;
                case 1:
                    while(typeof $(focuseditem).next().attr('class') !== 'undefined' && ($(focuseditem).next().attr('class').indexOf('hide') !== -1 || $(focuseditem).next().attr('class').indexOf('subtitlefile') !==-1)){
                        focuseditem = $(focuseditem).next();
                    }
                    if(typeof $(focuseditem).next().attr('class') === 'undefined'){
                        focusbrowseritem();
                        return;
                    }
                    focuseditem = $(focuseditem).next();
                break;
            }
        break;
        case 2:
            switch(direction){
                case 0:
                    if(typeof $(focuseditem).prev().attr('class') === 'undefined'){
                        focuseditem = $('#theplaylist').children().eq($('#theplaylist').children().length-1);
                    }
                    else
                        focuseditem = $(focuseditem).prev();
                break;
                case 1:
                    if(typeof $(focuseditem).next().attr('class') === 'undefined'){
                        focuseditem = $('#theplaylist').children().eq(0);
                    }
                    else
                        focuseditem = $(focuseditem).next();
                break;
            }
        break;
        case 3:
            switch(direction){
                case 0:
                    if(typeof $(focuseditem).prev().attr('class') === 'undefined'){
                        focuseditem = $('#playlistsul').children().eq($('#playlistsul').children().length-1);
                    }
                    else
                        focuseditem = $(focuseditem).prev();
                break;
                case 1:
                    if(typeof $(focuseditem).next().attr('class') === 'undefined'){
                        focuseditem = $('#playlistsul').children().eq(0);
                    }
                    else
                        focuseditem = $(focuseditem).next();
                break;
            }
        break;
    }
    $(focuseditem).addClass('focus');
    $(focuseditem)[0].scrollIntoView();
}

function switchcontaineroffocus(){
    switch(containeroffocus){
        case false:
            containeroffocus = 1;
            focusbrowseritem();
        break;
        case 0:/*searchform*/
            containeroffocus = 1;
            focusbrowseritem();
        break;
        case 1:/*mainlist*/
            containeroffocus = 2;
            rememberedfocused[1] = focuseditem;
            $(focuseditem).removeClass('focus');
            if(rememberedfocused[2] !== false){
                focuseditem = rememberedfocused[2];
                $(focuseditem).addClass('focus');
            }
            else{
                $('#theplaylist').children().eq(0).addClass('focus');
                focuseditem = $('#theplaylist').children().eq(0);   
            }
        break;
        case 2:/*playlist*/
            containeroffocus = 1;
            rememberedfocused[2] = focuseditem;
            $(focuseditem).removeClass('focus');
            
            if(rememberedfocused[1] !== false && $(rememberedfocused[1]).attr('class').indexOf('hide') === -1){
                focuseditem = rememberedfocused[1];
                $(focuseditem).addClass('focus');
                filedescripttotal();
            }
            else{
                focusbrowseritem();   
            }
        break;
        case 3:
            
        break;
        default:
        break;
    }
}

function showsearchform(){
    $('#search').addClass('active');
    
    if(focuseditem !== false){
        $(focuseditem).removeClass('focus');
    }
    containeroffocus = 0;
    $('#thesearchinput').focus();
    searchshortcut = true;
}

function closetheplay(){
    newplayer = ' <a href="" id="player"></a>';
    audio.pause();
    $('#player').replaceWith(newplayer);
    $('#filelist').addClass('active');
    $('#theplaylist').addClass('active').removeClass('playing');
    $(currentplaying).removeClass('playing');
    $('#viwdio').removeClass('active');
    
    
    $('#viwdio').addClass('minimized');
    $('#menuplayer').addClass('minimized');
    
    $('#playlisttitle').addClass('active');
    $('#minimize').addClass('minimized');
}

function showplaylistlist(){
    if($('#playlistcount').html().indexOf('0 ') !== 0){
        if(focuseditem !== false && (containeroffocus == 1 || containeroffocus == 2)){
            switch(containeroffocus){
                case 1:
                    rememberedfocused[1] = focuseditem;       
                break;
                case 2:
                    rememberedfocused[2] = focuseditem;
                break;
                default:
                break;
            }
        }
        
        $(focuseditem).removeClass('focus');
        if(containeroffocus == 3){
            if(rememberedfocused[1] !== false){
                containeroffocus = 1;
                focuseditem = rememberedfocused[1];
            }
            else if(rememberedfocused[2] !== false){
                containeroffocus = 2;
                focuseditem = rememberedfocused[2];
            }
            $(focuseditem).addClass('focus');
            $('#playlistslist').removeClass('active');
            return;
        }
        
        
        containeroffocus = 3;
        if(!playlistses.length){
            playlistobj.load(true);
        }
        else{
            var lists = '';
            var playingclass = '';
            for(var i=0;i<playlistses.length;i++){
                if(currentplaylist == playlistses[i].name){
                    playingclass ='playing';
                }
                else{
                    playingclass = '';        
                }
                lists += '<li class="fileitem '+playingclass+'"><span class="name">'+playlistses[i].name+'</span><span class="url">'+playlistses[i].name+'</span><span class="removelist">-</span></li>';
            }
            $('#playlistsul').html(lists);
            $('#playlistsul').children().eq(0).addClass('focus');
            focuseditem = $('#playlistsul').children().eq(0);
            rememberedfocused[3] = focuseditem;
            $('#playlistslist').addClass('active');                   
        }
    }
}

function enteritem(){
    if(typeof $('#playname').attr('class') !== 'undefined' && $('#playname').attr('class').indexOf('focused') !== -1){
        return;
    }
    if(focuseditem !== false){
        switch(containeroffocus){
            case 1:
                addtop($(focuseditem).children('.addtop'),false);
            break;
            case 2:
                playelem(focuseditem);
            break;
            case 3:
                $('#theplaylist').children('.playing').removeClass('playing');
                $(focuseditem).addClass('playing');
                currentplaylist = $(focuseditem).children('.name').html();
                playlistobj.playbtp($(focuseditem).children('.name').html());
            break;
        }
    }
}

function showsaveplaylistdialog(){
    if($('#theplaylist').children().length){
        if($('#playlistcount').html() !== '0 playlist'){
            if(!playlistses.length){
                playlistobj.load(false);    
            }
            else{
                var lists = '';
                var playn = '';
                var playnidx = false;
                for(var i=0;i<playlistses.length;i++){
                    if(currentplaylist == playlistses[i].name){
                        playnidx = i;
                        playn = 'playing';
                    }
                    else{
                        playn = '';
                    }
                    lists += '<li class="fileitem '+playn+'"><span class="name">'+playlistses[i].name+'</span><span class="url">'+playlistses[i].name+'</span><span class="removelist">-</span></li>';
                }
                var listb = $('#saveplaylistdialog').find('.playlist');
                if($(listb).length){
                    $(listb).html(lists);
                }
                else{
                    $('#saveplaylistdialog').children('.row.head').after('<ul class="playlist" id="anotherplaylist">'+lists+'</ul>');   
                }
                $('#saveplaylistdialog').addClass('active');
                if(currentplaylist != ''){
                    $('#playname').val(currentplaylist);
                    $('#anotherplaylist').children('.playing')[0].scrollIntoView();
                }
            }
        }
        else{
            var listb = $('#saveplaylistdialog').find('.playlist');
            if($(listb).length){
                $(listb).remove();
            }
            $('#saveplaylistdialog').addClass('active');
        }
        setTimeout(function(){
            $('#playname').focus();
        },300);
    }
}
function showbookmarkpos(postitle){
    $('#seekandvolnotif').find('.message').html('<span style="font-size:14px">'+postitle+'</span>');
    $('#seekandvolnotif').addClass('active');
    setTimeout(function(){
        $('#seekandvolnotif').animate({'opacity':0},'fast',function(){
            $('#seekandvolnotif').removeClass('active');
            $('#seekandvolnotif').css('opacity',0.3);
        });
    },5000);
}
function showseekvolnotif(){
    $('#seekandvolnotif').find('.message').html(seekandvolmsg);
    $('#seekandvolnotif').addClass('active');
    setTimeout(function(){
        $('#seekandvolnotif').animate({'opacity':0},'fast',function(){
            $('#seekandvolnotif').removeClass('active');
            $('#seekandvolnotif').css('opacity',0.3);
        });
    },5000);
}

function loadmenu(spanitem){
    if($(spanitem).attr('class') === 'active'){
        $.each($('#browser').children(),function(i,v){
           addtop($(v).children('.addtop'),false); 
        });
        return;
    }
    $('#filelist').addClass('loading');
    $(spanitem).siblings('.active').removeClass('active');
    $(spanitem).addClass('active');
    
    for(var i=0;i<thelists.length;i++){
        if(thelists[i].name == $(spanitem).html()){
            if(thelists[i].content === ''){
                loadfolder(thelists[i].name);
            }
            else{
                $('#browser').html(thelists[i].content);
                $('#filesdescript').html($('#browser').children().length+' files found');
                $('#filelist').removeClass('loading');
                
                if(containeroffocus == 1){
                    focusbrowseritem();
                }
            }
            break;
        }
    }
}

function toggleplaylist(){
    if($('#minimize').attr('class').indexOf('minimized') !== -1){
        return;
    }
    if($('#theplaylist').attr('class').indexOf('active') === -1){
        if(focuseditem !== false){
            rememberedfocused[containeroffocus] = focuseditem;
            $(focuseditem).removeClass('focus');
        }
        
        containeroffocus = 2;
        focuseditem = $('#theplaylist').children('.playing');
        $(focuseditem).addClass('focus');

        
        $('#theplaylist').addClass('active playing');
        $('#theplaylist').children('.playing')[0].scrollIntoView();
    }
    else{
        $('#theplaylist').removeClass('active playing');
        $('#playlisttitle').removeClass('active');
    }
}

function togglefullscreen(athis){
    if($(athis).attr('class').indexOf('minimized') === -1){
        $('#viwdio').addClass('minimized');
        $('#menuplayer').addClass('minimized');
        
        $('#theplaylist').addClass('active').removeClass('playing');
        $('#playlisttitle').addClass('active');
        $(athis).addClass('minimized');
        $('#filelist').addClass('active');
    }
    else{
        $(athis).removeClass('minimized');
        $('#viwdio').removeClass('minimized');
        $('#menuplayer').removeClass('minimized');
        $('#filelist').removeClass('active');
        $('#theplaylist').removeClass('active');
        $('#playlisttitle').removeClass('active');
        
        setTimeout(function(){
            $('#menuplayer').removeClass('hovered');
        },3000);
    }
}
function togglerepeat(athis){
    switch($(athis).attr('class')){
        case 'all':
            $(athis).html('1').removeClass('all').addClass('one');
            repeatplaylist = 'one';
        break;
        case 'one':
            $(athis).html('off').removeClass('one').addClass('off');
            repeatplaylist = 'off';
        break;
        case 'off':
            $(athis).html('all').removeClass('off').addClass('all');
            repeatplaylist = 'all';
        break;
    }
}

function toggleshuffle(athis){
    switch($(athis).attr('class')){
        case 'off':
            $(athis).html('on').removeClass('off').addClass('on');
            shuffleround = 0;
            $('#theplaylist').children().removeClass('shuffleround_'+shuffleround);
            $('#theplaylist').children().removeClass('shuffleround_'+(shuffleround+1));
            $('#theplaylist').children().addClass('shuffleround_0');
            shuffle = true;
        break;
        case 'on':
            $(athis).html('off').removeClass('on').addClass('off');
            shuffle = false;
        break;                
    }
}

function loadfolder(name){
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'home',d:{type:name}}
    }).done(function(msg){
        msg = JSON.parse(msg);
        var newlist = msg.pagecontent;
        $('#browser').html(newlist);
        subfind.updatesubs();
        
        $('#filesdescript').html(msg.filescount+' files found');
        $('#filelist').removeClass('loading');
        var i = thelists.length;
        thelists[i] = [];
        thelists[i].content = $('#browser').html();
        thelists[i].name = name;
        
        if(containeroffocus == 1){
            focusbrowseritem();
        }
    });
}

var playlistobj = {
    delete:function(name){
        var pidx = false;
        for(var i=0;i<playlistses.length;i++){
            if(playlistses[i].name == name){
                pidx = i;
                break;
            }
        }
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'playlist',a:'delete',d:{name:playlistses[pidx].name}}
        }).done(function(msg){
            playlistses.splice(pidx,1);
            $('#playlistsul').children().eq(pidx).remove();
            $('#playlistcount').html(playlistses.length+' playlists');
        });
    },
    playbtp:function(name){
        var pidx = false;
        for(var i=0;i<playlistses.length;i++){
            if(playlistses[i].name == name){
                pidx = i;
                break;
            }
        }
        $('#playlisttitle').html(name).removeClass('unsaved');
            $.ajax({
                url:'./',
                type:'POST',
                data:{app:appname,p:'playlist',a:'items',d:{name:playlistses[pidx].name}}
            }).done(function(msg){
                msg = JSON.parse(msg);
                $('#theplaylist').html('');
                $.each(msg.items,function(i,v){
                    var news = '<li class="fileitem"><div class="name">'+v.name+'</div><div class="url">'+v.path+'</div><div class="removelist">-</div><div class="movethelist">&nbsp;</div><div class="downloaditem">&nbsp;</div></li>';
                    $('#theplaylist').append(news);
                });
                
                $('#playlisttitle').html($('#playlisttitle').html()+'('+msg.items.length+')');
                
                lastplayeditem = false;
                if(msg.lastplayed.length){
                    $.each(msg.lastplayed,function(bi,be){
                        lastplayeditem = be.item;
                    });   
                }
                
                bonusitems = [];
                if(msg.bonuselems.length){
                    $.each(msg.bonuselems,function(bi,be){
                        bidx = bonusitems.length;
                        bonusitems[bidx] = [];
                        bonusitems[bidx].type   = be.type;
                        bonusitems[bidx].val    = be.val;
                        bonusitems[bidx].item   = be.item;
                    });   
                }
                
                $('#playlistslist').removeClass('active');
                
                if(lastplayeditem !== false){
                    containeroffocus = 2;
                    $.each($('#theplaylist').find('.url'),function(iu,ii){
                       if($(ii)[0].innerText == lastplayeditem){
                            focuseditem = $(ii).parent();  
                            return false;
                       } 
                    });
                    $(focuseditem).addClass('focus');
                    rememberedfocused[2] = focuseditem;
                }
                else{
                    containeroffocus = false;
                    focuseditem = false;
                    rememberedfocused[2] = focuseditem;
                }
                multiplaynav(1);
            });
    },
    load:function(mode){
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'playlist',a:'thelist'}
        }).done(function(msg){
            msg = JSON.parse(msg);
            var lists = '';
            $.each(msg,function(mi,mb){
                lists += '<li class="fileitem"><span class="name">'+mb.nicename+'</span><span class="url">'+mb.path+'</span><span class="removelist">-</span></li>';
                
                playlistses[playlistses.length] = [];
                playlistses[playlistses.length-1].name = mb.nicename;
                playlistses[playlistses.length-1].items = false;
            });
            $('#playlistsul').html(lists);
            if(mode){
                $('#playlistslist').addClass('active');
                $('#playlistsul').children().eq(0).addClass('focus');
                
                focuseditem         = $('#playlistsul').children().eq(0);
                containeroffocus    = 3;
            }
            else{
                $('#saveplaylistdialog').children('.row.head').after('<ul class="playlist" id="anotherplaylist">'+lists+'</ul>');
                $('#saveplaylistdialog').addClass('active');
            }
        });
    },
    save:function(pidx){
        var pidxx = false;
        for(var i=0;i<playlistses.length-1;i++){
            if(playlistses[i].name == playlistses[pidx].name){
                pidxx = i;
                break;
            }
        }
        if(pidxx !== false){
            playlistses[pidxx].items = playlistses[pidx].items;
            playlistses.splice(pidx,1);
            pidx = pidxx;
        }
        
        var urls = '';
        for(var i=0;i<playlistses[pidx].items.length;i++){
            urls+=playlistses[pidx].items[i]+'<*edsep*>';
        }
        for(var i=0;i<bonusitems.length;i++){
            urls+=bonusitems[i].type+'<^bonuselem^>'+bonusitems[i].val+'<^bonuselem^>'+bonusitems[i].item+'<*edsep*>';
        }
        
        if(lastplayeditem !== false){
            urls+=lastplayeditem+'<^lastplayedelem^><*edsep*>';
        }
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'playlist',a:'save',d:{name:playlistses[pidx].name,urls:urls}}
        }).done(function(msg){
            $('#saveplaylistdialog').children('.row').eq(0).html('Save Playlist');
            $('#playname').val('name');
            $('#saveplaylistdialog').removeClass('active');
            $('#playlistcount').html(playlistses.length+' playlists');
            $('#playlisttitle').html(playlistses[pidx].name).removeClass('unsaved');
        });
    }
};

function endplaying(){
    var nexttoplay = randomelem();
    if(nexttoplay === false){
        return;
    }
    playnext();
}

function addtop(elem,play){
    elem = $(elem).parent();
    var shuffleclas = shuffle ? 'shuffleround_'+shuffleround : '';
    var newitem = '<li class="fileitem '+shuffleclas+'"><div class="name">'+$(elem).children('.name').html()+'</div><div class="url">'+$(elem).children('.url').html()+'</div><div class="removelist">-</div><div class="movethelist">&nbsp;</div><div class="downloaditem">&nbsp;</div></div></li>';
    $('#theplaylist').append(newitem);
    $('#playlisttitle').addClass('unsaved');
    var intheplaylist = $('#theplaylist').children().length;
    elem = $('#theplaylist').children().eq(intheplaylist-1);
    if(intheplaylist > 1){
        multiplaynav(1);
    }
        
    if(play)
    {
        if(shuffle){
            $(currentplaying).removeClass('shuffleround_'+shuffleround).addClass('shuffleround_'+(shuffleround+1));
        }
        playelem(elem);
    }
}
function playelem(elem){
    var url = $(elem).children('.url')[0].innerText;
    lastplayeditem = url;
    playitem(url);
    $(currentplaying).removeClass('playing');
    currentplaying = elem;
    
    $(currentplaying).addClass('playing');
    $(currentplaying)[0].scrollIntoView();
    
    if($('#viwdio').attr('class').indexOf('active') === -1)
        $('#viwdio').addClass('active');
}

function randomelem(){
    var listlength = $('#theplaylist').children('.shuffleround_'+shuffleround).length;
    if(!listlength){
        if(repeatplaylist == 'off'){
            return false;
        }
        shuffleround +=1;
        listlength = $('#theplaylist').children('.shuffleround_'+shuffleround).length;
    }
    var winer = Math.floor(Math.random() * listlength);
    return $('#theplaylist').children('.shuffleround_'+shuffleround).eq(winer);
}

function playnext(){
    if(repeatplaylist == 'one'){
        playelem(currentplaying);
        return;
    }
    previousplay = currentplaying;
    var nexttoplay;
    if(shuffle){
        if($(currentplaying).attr('class').indexOf('shuffleround_') === -1){
            $('#theplaylist').children().addClass('shuffleround_'+shuffleround);
        }
        $(currentplaying).removeClass('shuffleround_'+shuffleround).addClass('shuffleround_'+(shuffleround+1));
        nexttoplay = randomelem();
        if(nexttoplay === false && navigatefrombutton){
            navigatefrombutton = false;
            shuffleround +=1;
            nexttoplay = randomelem();     
        }
    }
    else
        nexttoplay = $(currentplaying).next();
        
    if(typeof $(nexttoplay).attr('class') !== 'undefined' && $(nexttoplay).attr('class').indexOf('fileitem') !== -1){
        playelem(nexttoplay);
    }
    else{
        if(multiplaynavflag && repeatplaylist === 'all'){
            playelem($('#theplaylist').children().eq(0));
        }
    }
    navigatefrombutton = false;
}
function playprev(){
    if(shuffle && previousplay !== false){
        playelem(previousplay);
        return;
    }
    var nexttoplay = $(currentplaying).prev();
    
    if(typeof $(nexttoplay).attr('class') !== 'undefined' && $(nexttoplay).attr('class').indexOf('fileitem') !== -1){
        playelem(nexttoplay);
    }
    else{
        if(multiplaynavflag){
            var intheplaylist = $('#theplaylist').children().length;
            playelem($('#theplaylist').children().eq(intheplaylist-1));
        }
    }
}
function multiplaynav(mode){
    if(mode){
        multiplaynavflag = true;
        $('#nextplay').addClass('active');
        $('#prevplay').addClass('active');   
    }
    else{
        multiplaynavflag = false;
        $('#nextplay').removeClass('active');
        $('#prevplay').removeClass('active');   
    }
}
function filterbrowser(typed){
    typed = typed.toLowerCase();
    var filteredcount = 0;
    var filterflagtemp = filterflag;
    var brocken = false;
    $.each($('#browser').children(),function(){
        if(filterflagtemp != filterflag){
            brocken = true;
            return false;
        }
        if($(this).children('.name').html().toLowerCase().indexOf(typed) === -1){
           $(this).addClass('hide');
        }
        else{
           $(this).removeClass('hide');
           filteredcount++;
        }
    });
    if(!brocken){
        $('#filesdescript').html(filteredcount+' files found');
        if(containeroffocus == 2){
            if(focuseditem !== false){
                rememberedfocused[2] = focuseditem;
                $(focuseditem).removeClass('focus');
            }
        }
        else if(containeroffocus == 1){
            if(focuseditem !== false){
                $(focuseditem).removeClass('focus');
            }
        }
        containeroffocus = 1;
        focusbrowseritem();
    }
}
function searchput(){
    if(searchputdont){
        searchputdont = false;
    }
}
function clearsearch(){
    if($('#thesearchinput').val() == ''){
        $('#search').removeClass('active'); 
        $(rememberedfocused[1]).removeClass('focus');
        $(focuseditem).removeClass('focus');
        focuseditem = false;
        rememberedfocused[1] = false;
        containeroffocus = 0;
        switchcontaineroffocus();
        return;
    }
    setTimeout(function(){
        if(!searchputdont){
            $('#thesearchinput').val('');
            filterflag++;
            $('#browser').children('.hide').removeClass('hide');
            $('#search').removeClass('active'); 
            
            $(rememberedfocused[1]).removeClass('focus');
            $(focuseditem).removeClass('focus');
            rememberedfocused[1] = false;
            focuseditem = false;
            containeroffocus = 0;
            switchcontaineroffocus();
            return;
        }
        $('#thesearchinput').focus();
    },500);
}

function markplace(afileitem,direct){
    $('#theplaylist').children().removeClass('markednext markedprev');
    
    if((typeof $(afileitem).next().attr('class') !== 'undefined' && direct == false) || direct == 'next'){
        $(afileitem).next().addClass('markedprev');
        return $(afileitem).next();
    }
    else if( (typeof $(afileitem).prev().attr('class') !== 'undefined') || direct == 'prev'){
        if($(afileitem).prev().attr('class').indexOf('moving') !== -1){
            afileitem = $(afileitem).prev();
        }
        
        $(afileitem).prev().addClass('markedprev');
        return $(afileitem).prev();
    }
    else{
        return false;
    }
}
function filehandler(){
    $('body').delegate('.movethelist','mousedown',function(event){
        event.stopPropagation();
        if(movinglist !== false){
            return;
        }
        movetheliststartx = event.clientX;
        movingitemposition = (event.clientY-5);
        var listitem = movinglist  = $(this).parent();
        marked = markplace(listitem,false);
        
        if(marked === false){
            return;
        }
        
        $(listitem).addClass('moving');
        movingstartx = $('#theplaylist')[0].offsetLeft+27;
        $(listitem).css('width',$('#theplaylist').width()+'px');
        $(listitem).css('left',(movingstartx));
        $(listitem).css('top',movingitemposition);
        
        
        $(this).on('mousemove',function(event){
            event.stopPropagation();
            var movingitempositionx = movingstartx + (event.clientX - movetheliststartx);
            var movingitempositiony = (event.clientY-5);
            $(listitem).css('top',movingitempositiony);
            $(listitem).css('left',movingstartx);
            if(movingitempositiony > movingitemposition && movingitempositiony  - movingitemposition > 30){
                movingitemposition = movingitempositiony;
                marked = markplace(marked,'next');
            }
            else if(movingitempositiony < movingitemposition && movingitemposition - movingitempositiony > 30){
                movingitemposition = movingitempositiony;
                marked = markplace(marked,'prev');
            }
        });
        
        $(this).on('mouseup',function(event){
            event.stopPropagation();
            var moved = '<li class="fileitem">'+$(movinglist).html()+'</li>';
            $(movinglist).remove();
            if($(marked).attr('class').indexOf('markedprev') !== -1){
                $(marked).after(moved).removeClass('markedprev markednext');    
            }
            else{
                $(marked).before(moved).removeClass('markedprev markednext');
            }
            $('#playlisttitle').addClass('unsaved');
            movinglist = false;
        });
    });
    
    $('body').delegate('.fileitem','click',function(event){
        event.stopPropagation();
        var parent = $(this).parent();
        
        if($(parent).attr('id') == 'browser'){
            searchputdont = true;

            if(focuseditem !== false){
                rememberedfocused[containeroffocus] = focuseditem;
                $(focuseditem).removeClass('focus');
            }
            containeroffocus = 1;
            focuseditem = this;
            $(focuseditem).addClass('focus');
            
            addtop($(this).children('.addtop'),true);
            setTimeout(function(){
                searchput();
            },500);
        }
        else if($(parent).attr('id') == 'playlistsul'){
            $(parent).children('.playing').removeClass('playing');
            $(this).addClass('playing');
            currentplaylist = $(this).children('.name').html();
            playlistobj.playbtp($(this).children('.name').html());
        }
        else if($(parent).attr('class') == 'playlist'){
            $(parent).children('.playing').removeClass('playing');
            $(this).addClass('playing');
            $('#playname').val($(this).children('.name').html());
        }
        else{
            playelem(this);
            if(focuseditem !== false){
                $(focuseditem).removeClass('focus');
            }
            containeroffocus = 2;
            focuseditem = this;
            $(focuseditem).addClass('focus');
        }
    });
    
    $('body').delegate('#saveplaylistsubmit','click',function(event){
        event.stopPropagation();
        if($('#playname').val() == '' || $('#playname').val() == 'name'){
            return;
        }
        currentplaylist = $('#playname').val();
        var playlistitems = [];
        $.each($('#theplaylist').children(),function(i,v){
            playlistitems[playlistitems.length] = $(v).children('.url').html();
        });
        playlistses[playlistses.length] = [];
        playlistses[playlistses.length-1].name = $('#playname').val();
        playlistses[playlistses.length-1].items = playlistitems;
        playlistobj.save(playlistses.length-1);
        
        $(this).parent().parent().children('.row').eq(0).html('saving...');
    });  
    
    $('body').delegate('#saveplaylist','click',function(event){
        event.stopPropagation();
        showsaveplaylistdialog();
    });  
    
    $('body').delegate('.closemodal','click',function(event){
        event.stopPropagation();
        $(this).parent().removeClass('active');
        focusbrowseritem();
    });   
    
    $('body').delegate('#clearplaylist','click',function(event){
        event.stopPropagation();
        currentplaylist = '';
        $('#theplaylist').html('');
        $('#playlisttitle').html('untitled');
    });  

    $('body').delegate('#playlistcount','click',function(event){
        event.stopPropagation();
        showplaylistlist();
    });    
    
    
    $('body').delegate('#thesearchinput','keyup',function(event){
        event.stopPropagation();
        switch(event.which){
            case 27:
                clearsearch();   
            break;
            case 17:
                switchcontaineroffocus();    
            break;
            case 38:
                event.preventDefault();
                navlistitem(0);
            break;
            case 40:
                event.preventDefault();
                navlistitem(1);
            break;
            case 13:
                enteritem();
            break;
            default:
                if(event.which == 87 && searchshortcut === true){
                    searchshortcut = false;
                    $(this).val('');
                }
                else{
                    filterflag++;
                    filterbrowser($('#thesearchinput').val());     
                }
            break;
        }
        
    });
    $('body').delegate('#thesearchinput','blur',function(event){
        event.stopPropagation();
        clearsearch();
    });
    
    $('body').delegate('#search','click',function(event){
        event.stopPropagation();
        showsearchform();
    });
    $('body').delegate('#reload','click',function(event){
        event.stopPropagation();
        $('#filelist').addClass('loading');
        loadfolder($('#filemenu').children('.active').html());
    });
    $('body').delegate('#nextplay','click',function(event){
        event.stopPropagation();
        navigatefrombutton = true;
        playnext();
    });
    $('body').delegate('#prevplay','click',function(event){
        event.stopPropagation();
        playprev();
    });
    
    $('body').delegate('#bookmarkses','click',function(event){
        event.stopPropagation();
        if(typeof $('#bookmarkedpoints').attr('class') == 'undefined' || $('#bookmarkedpoints').attr('class').indexOf('active') == -1){
            $('#bookmarkedpoints').addClass('active');    
        }
        else{
            $('#bookmarkedpoints').removeClass('active');
        }
    });
    
    $('body').delegate('.removeboni','click',function(event){
        event.stopPropagation();
        markisd = ($(this).parent().children('.bonival').html());
        var cpath = false;
        switch(mediatypeflag){
            case 1:
                cpath = $('#audioplayer').attr('src');;
            break;
            case 0:
                cpath = $(vaudio).children().attr('src');
            break;
            default:
            break;
        }
        for(var i=0;i<bonusitems.length;i++){
            if(bonusitems[i].item == cpath && bonusitems[i].val == markisd){
                bonusitems.splice(i,1);
                break;
            }
        }
        if($(this).parent().parent().children().length > 1){
            $(this).parent().remove();
        }
        else{
            $(this).parent().remove();    
            $('#bookmarkses').removeClass('active');
        }
        $('#playlisttitle').addClass('unsaved');
    });
    
    $('body').delegate('.bonusitemsitem','click',function(event){
        event.stopPropagation();
        $('.bonusitemsitem').removeClass('beenthere');
        $(this).addClass('beenthere');
        
        markisd = ($(this).children('.bonival').html());
        switch(mediatypeflag){
            case 1:
                audio.currentTime = markisd;
                
            break;
            case 0:
                vaudio.currentTime = markisd;
            break;
            default:
            break;
        }
        $('#bookmarkedpoints').removeClass('active');
    });
    
    
    $('body').delegate('#addbookmarkses','click',function(event){
        event.stopPropagation();
        handleaddmarks();
    });
    
    $('body').delegate('.removefileitem','click',function(event){
        event.stopPropagation();
        
        deletefileitem(this);
    });
     $('body').delegate('.renamefileitem','click',function(event){
        event.stopPropagation();
        
        renamefileitem(this);
    });
    
    
    $('body').delegate('.addtop','click',function(event){
        event.stopPropagation();
        
        searchputdont = true;
        addtop(this,false);
        
        if(focuseditem !== false){
            rememberedfocused[containeroffocus] = focuseditem;
            $(focuseditem).removeClass('focus');
        }
        
        containeroffocus = 1;
        focuseditem = $(this).parent();
        $(focuseditem).addClass('focus');
        
        $('#browser').blur();
            
        setTimeout(function(){
            searchput();
        },1000);
    });
    $('body').delegate('.removelist','click',function(event){
        event.stopPropagation();
        
        if($(this).parent().attr('class').indexOf('focus') !== -1){
            if(typeof $(this).parent().prev().attr('class') !== 'undefined'){
                focuseditem = $(this).parent().prev();
            }
            else{
                focuseditem = $(this).parent().next();
            }
            $(focuseditem).addClass('focus');
        }
        
        
        if($(this).parent().parent().attr('id') == 'playlistsul'){
            $('#playlistslist').removeClass('active');
            playlisttodelete = $(this).siblings('.name').html();
            
            var boxtitle = 'remove playlist confirmation';
            var boxcontent = 'delete playlist '+playlisttodelete+'?';
            var boxaction = '<span id="deleteplaylist">delete</span>';
            
            dialogbox(boxtitle,boxcontent,boxaction);
            
            $('#deleteplaylist').on('click',function(event){
                event.stopPropagation();
                playlistobj.delete(playlisttodelete);
                confirmbox.close();
            });
            
            return;
        }
        var elem = $(this).parent();
        $(elem).remove();
        if($('#theplaylist').children().length <= 1){
            multiplaynav(0);
        }
    });
    
    $('body').delegate('#minimize','click',function(event){
        event.stopPropagation();
        togglefullscreen(this);
    });
    
    $('body').delegate('#showplaylist','click',function(event){
        event.stopPropagation();
        toggleplaylist();
    });
    
    $('body').delegate('#closeplayer','click',function(event){
        event.stopPropagation();
        closetheplay();
    });
}
function handleaddmarks(){
    switch(mediatypeflag){
        case 1:
            markisd = audio.currentTime;
        break;
        case 0:
            markisd = vaudio.currentTime;
        break;
        default:
        break;
    }
    var atminute = (markisd/60);
    var approx = Math.round((atminute - Math.floor(atminute))*60);
    approx = approx <= 9 ? '0'+approx : approx;
    
    var boxtitle = 'add bookmark at '+ Math.floor(atminute)+':'+approx;
    var boxcontent = '<input type="text" value="bookmark name" name="bookmark name" id="bokmarkname">';
    var boxaction = '<span id="addandsavemark">save</span>';
    
    dialogbox(boxtitle,boxcontent,boxaction);
    $('#bokmarkname').focus().val('bookmark name');
    
    $('#bokmarkname').on('keydown',function(event){
        if($(this).val() == $(this).attr('name')){
            $(this).val('');
        }
        if(event.which == 27){
            confirmbox.close();
        }
    });
    $('#bokmarkname').on('keyup',function(event){
        if($(this).val() == ''){
            $(this).val($(this).attr('name'));
        }
        if(event.which == 13){
            event.stopPropagation();
            handleaddmarksubmit();
        }
    });
    $('#bokmarkname').on('blur',function(){
        if('' == $(this).val()){
            $(this).val($(this).attr('name'));
        }
    });
    
    $('#addandsavemark').on('click',function(event){
        event.stopPropagation();
        handleaddmarksubmit();
    });
    
}

function handleaddmarksubmit(){
    var idx;
    idx = bonusitems.length;
    switch(mediatypeflag){
        case 1:
            bonusitems[idx] = [];
            bonusitems[idx].type    = 'mark';
            bonusitems[idx].item    = $('#audioplayer').attr('src');
            bonusitems[idx].val     = markisd;
        break;
        case 0:
            bonusitems[idx] = [];
            bonusitems[idx].type    = 'mark';
            bonusitems[idx].item    = $(vaudio).children().attr('src');
            bonusitems[idx].val     = markisd;
        break;
        default:
        break;
    }
    bonusitems[idx].type = $('#bokmarkname').val();
    
    switch(mediatypeflag){
        case 0:
            handlebookmarks($(vaudio).children().attr('src'));        
        break;
        case 1:
            handlebookmarks($('#audioplayer').attr('src'));        
        break;
    }
    $('#playlisttitle').addClass('unsaved');
    if($('#minimize').attr('class').indexOf('minimized') === -1){
        togglefullscreen($('#minimize'));
    }
    confirmbox.close();
}

function renamefileitem(elem){
    var filerenameelem = elem;
    var boxcontent = '<input type="text" value="'+$(elem).siblings('.url').html()+'" id="nurl">';
    var boxaction = '<span id="renamefile" class="'+$(elem).siblings('.url').html()+'">rename</span>';
    
    dialogbox('Rename File',boxcontent,boxaction);
    
    $('#renamefile').on('click',function(event){
        event.stopPropagation();
        
        var url = $(this).attr('class');
        var nurl = $('#nurl').val();
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'ajax',a:'renamefile',d:{url:url,newurl:nurl}}
        }).done(function(msg){
            msg = JSON.parse(msg);
            if(msg.rename){
                confirmbox.close();
                
                if($('#theplaylist').children().length)
                $.each($('#theplaylist').children(),function(oi,oe){
                    if($(oe).children('.url').html() == $(filerenameelem).siblings('.url').html()){
                        $(oe).children('.url').html(nurl);
                        $(oe).children('.name').html(msg.nicename);
                    }
                });
                $(filerenameelem).siblings('.name').html(msg.nicename);
                $(filerenameelem).siblings('.url').html(nurl);
            }
            else{
                $('#messageboxcontent').find('.tablecell').html('error renaming file');
            }
        });
    });
}
function deletefileitem(elem){
    var fileitemdeleteelem = elem;
    var boxcontent = 'delete item '+$(elem).siblings('.url').html()+'?';
    var boxaction = '<span id="deletefitem" class="'+$(elem).siblings('.url').html()+'">delete</span>';
    
    dialogbox('Delete File',boxcontent,boxaction);
    
    $('#deletefitem').on('click',function(event){
        event.stopPropagation();
        
        var url = $(this).attr('class');
        $.ajax({
            url:'./',
            type:'POST',
            data:{app:appname,p:'ajax',a:'deletefile',d:{url:url}}
        }).done(function(msg){
            if(msg){
                confirmbox.close();
                
                if($('#theplaylist').children().length)
                $.each($('#theplaylist').children(),function(oi,oe){
                    if($(oe).children('.url').html() == $(fileitemdeleteelem).siblings('.url').html()){
                        $(oe).remove();
                    }
                });
                $(fileitemdeleteelem).parent().remove();
            }
            else{
                $('#messageboxcontent').find('.tablecell').html('error deleting file');
            }
        });
    });
}
function handlebookmarks(path){
    if(bonusitems.length){
        var activate = false;
        var bonusli= '<ul id="bookmarkedpoints" class="mplaya">';
        for(var i=0;i<bonusitems.length;i++){
            if(bonusitems[i].item == path){
                activate = true;
                bonusli += '<li class="bonusitemsitem mplaya"><span class="removeboni mplaya">X</span><span class="boniname mplaya">'+bonusitems[i].type+'</span><span class="bonival mplaya">'+bonusitems[i].val+'</span></li>';
            }
        }
        
        if(!activate){
            $('#bookmarkses').removeClass('active');
        }
        else{
            bonusli += '</ul>'
            $('#bookmarkses').addClass('active').html('&para;'+bonusli);
        }
    }
    else{
        $('#bookmarkses').removeClass('active');
    }
}
function encodeur(url){
    url = encodeURIComponent(url).replace(/'/g,"%27").replace(/"/g,"%22");
    return encodeURIComponent(url).replace(/'/g,"%27").replace(/"/g,"%22");
}

var subfind = {
    subs:[],
    updatesubs:function(){
        var sfs =$('#browser').find('.subtitlefile');
        if(!sfs.length)
            return;
            
        var subidx;
        for(var i=0;i<sfs.length;i++){
            subidx = this.subs.length;
            this.subs[subidx] = [];
            this.subs[subidx].path = $(sfs[i]).children('.url')[0].innerText;
            this.subs[subidx].sub = this.subs[subidx].path.split('/');
            
            this.subs[subidx].fname = this.subs[subidx].sub[this.subs[subidx].sub.length-1].split('.');
            this.subs[subidx].fname.splice(this.subs[subidx].fname.length-1,1);
            this.subs[subidx].fname = this.subs[subidx].fname.join('.');
            
            this.subs[subidx].sub.splice(this.subs[subidx].sub.length-1,1);
            this.subs[subidx].sub = this.subs[subidx].sub.join('/')+'/'+this.subs[subidx].fname;
        }
    },
    findsub:function(path){
        if(!this.subs.length){
            return false;
        }
        path = path.split('/');
        var fname = path[path.length-1];
        fname = fname.split('.');
        fname.splice(fname.length-1,1);
        fname = fname.join('.');
        
        path.splice(path.length-1,1);
        path =  path.join('/')+'/'+fname;
        for(var i=0;i<this.subs.length;i++){
            if(this.subs[i].sub == path){
                return this.subs[i].path;
            }
        }
        return false;
    }
};
function playitem(path){
    handlebookmarks(path);
    var subexist = subfind.findsub(path);
    
    var pathx = path.split('/');
    for(var i=0;i<pathx.length;i++){
        pathx[i] = encodeur(pathx[i]);
    }
    pathx = pathx.join('/');
    
    var minim = $('#viwdio').attr('class').indexOf('minimized') === -1 ? false : true;
    
    if(!minim){
        $('#filelist').removeClass('active');
    }

    var filetype = path.split('.');
    filetype = filetype[filetype.length-1].toLowerCase();
    
    if(filetype.indexOf('mp4') !== -1 || filetype.indexOf('webm') !== -1 || filetype.indexOf('mkv') !== -1 || filetype.indexOf('3gp') !== -1|| filetype.indexOf('mov') !== -1){
        if(subexist === false){
            newplayer = '<video id="player" autoplay="false" controls="true"><source src="'+path+'"></video>';    
        }
        else{
            newplayer = '<video id="player" autoplay="false" controls="true"><source src="'+path+'"><track label="English" kind="subtitles" srclang="en" src="'+subexist+'" default></video>';
        }
        $('#player').replaceWith(newplayer);
        vaudio = $('#player')[0];
        
        vaudio.addEventListener('ended',endplaying);
        vaudio.addEventListener('canplay',function(){
            var timedur = vaudio.duration/60;
            $('#vtimedur').html(timedur.toFixed(2));
            vaudio.play();
            vaudio.volume = mediavolume;
        });
	    vaudio.addEventListener('volumechange',function(){
	        mediavolume = vaudio.volume;
	    });
		// Hide the default controls
		vaudio.controls = false;

		// Display the user defined vaudio controls
		vaudioControls.setAttribute('data-state', 'visible');

		// If the browser doesn't support the progress element, set its state for some different styling
		var progressBar = document.getElementById('progress-bar');
		var supportsProgress = (document.createElement('progress').max !== undefined);
		if (!supportsProgress) progress.setAttribute('data-state', 'fake');

		// Check if the browser supports the Fullscreen API
		var fullScreenEnabled = !!(document.fullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled || document.webkitSupportsFullscreen || document.webkitFullscreenEnabled || document.createElement('vaudio').webkitRequestFullScreen);
		// If the browser doesn't support the Fulscreen API then hide the fullscreen button
		if (!fullScreenEnabled) {
			fullscreen.style.display = 'none';
		}

		// Only add the events if addEventListener is supported (IE8 and less don't support it, but that will use Flash anyway)
		if (document.addEventListener) {
			// Wait for the vaudio's meta data to be loaded, then set the progress bar's max value to the duration of the vaudio
			vaudio.addEventListener('loadedmetadata', function() {
				progress.setAttribute('max', vaudio.duration);
			});
			// Add event listeners for vaudio specific events
			vaudio.addEventListener('play', function() {
				changeButtonState('playpause');
			}, false);
			vaudio.addEventListener('pause', function() {
				changeButtonState('playpause');
			}, false);

			// As the vaudio is playing, update the progress bar
			vaudio.addEventListener('timeupdate', function() {
				// For mobile browsers, ensure that the progress element's max attribute is set
				if (!progress.getAttribute('max')) progress.setAttribute('max', vaudio.duration);
				progress.value = vaudio.currentTime;
				$('#vtimepos').html((vaudio.currentTime/60).toFixed(4));
				progressBar.style.width = Math.floor((vaudio.currentTime / vaudio.duration) * 100) + '%';
			});
		}
	    $('#viwdio').removeClass('uncontrolled');
	    mediatypeflag = 0;
    }
    else if(filetype.indexOf('m4a') !== -1 || filetype.indexOf('mp3') !== -1 || filetype.indexOf('wav') !== -1){
        var newplayer = '<div class="table" id="player"><div class="tablecell"><video id="audioplayer" style="height: 28px; width: 66%;" controls="true" autoplay="true"></video></div></div>';
        $('#player').replaceWith(newplayer);
        audio = $('#audioplayer')[0];
        mediastarttime = 0;
        
        audio.src = path;
        
        audio.addEventListener('ended',endplaying);
	    audio.addEventListener('canplay',function(){
	        audio.play();
	        audio.volume = mediavolume;
	    });
	    audio.addEventListener('volumechange',function(){
	        mediavolume = audio.volume;
	    });
	    mediatypeflag = 1;
	    $('#viwdio').addClass('uncontrolled');
    }
    else{
        newplayer = ' <a href="" id="player"></a>';
        $('#player').replaceWith(newplayer);
        $('#player').prop('href',pathx);
        flowplayer("player", "./res/flowplayer/flowplayer-3.2.16.swf", {
            /*supply the configuration*/
        });
        mediatypeflag = 2;
        $('#viwdio').addClass('uncontrolled');
    }
    if(!minim){
        $('#viwdio').addClass('active');   
    }
}
