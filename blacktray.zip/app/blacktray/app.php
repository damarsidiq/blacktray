<?php

if(!class_exists('Pxpedia')){
	die();
}

Class App extends Pxpedia{
    /*website*/
    function __construct(){
		parent::__construct();
		
    }
}


