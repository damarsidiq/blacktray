<?php

Class Home extends Controller{
    var $encodingdest = 'UTF-8';
    var $paths = array();
    var $unsets = array();
    var $pls = '';
    function __construct() {
        parent::__construct();
        
        $this->pls = App::getConfig('uploads');
        
        $this->paths['flvmp3s'] = '../pxdrive/uploads/extdrive/leisure/music/flvmp3s';
        $this->paths['p'] = '../pxdrive/uploads/extdrive/backup/website/foreseller/post-meta/lib/views/setting/xv';
        $this->paths['concert'] = '../pxdrive/uploads/extdrive/leisure/music/concert';
        $this->paths['movies'] = '../pxdrive/uploads/extdrive/leisure/muvi';
        $this->paths['lectures'] = '../pxdrive/uploads/extdrive/leisure/lectures';
        
        $this->unsets = array('flv','mp3','mp4','m4a','mov','webm','btp','wmv','mkv','vtt');
        
        if(App::isMobile()){
             $this->addheadfootsrc(false,array('mobile'=>App::getConfig('appviews').'/styles/mobile.css'));
        }
    }
      public function securecheck($data){
        $this->setPagevar('ajax',true);
        $passwd = 'e2782f23454bc665f315a32c568fb985';
        $response['result'] = false;
        if(md5($data['pass']) == $passwd){
            $response['result'] = true;
        }
        else{
            $this->setPagevar('response',$response);
            return 'ajax';
        }
        
        
        
         $itemtype = array('p'=>$this->paths['p']);
            
            if(isset($data['type'])){
                $paths = array($data['type']=>$this->paths[$data['type']]);
            }
            else{
                $data['type'] = 'p';
                $paths = array('p'=>$this->paths['p']);
            }
            
            foreach($paths as $k=>$v){
                $files = $this->getFiles($v);
                $files = $this->controller('sortfile')->pageInit($files);
            }
            
            
                foreach($itemtype as $k=>$v){
                    $itemtype[$k] = [];
                    $itemtype[$k]['default'] = $k == $data['type'] ? 'active' : '';
                }   
                $this->setPagevar('itemtype',$itemtype);
                $this->setPagevar('files',$files);
                $this->setPagevar('filescount',count($files));
                $playlists = $this->getFiles($this->pls);
                $this->setPagevar('playlistcount',count($playlists));
                 $this->setPagevar('response',$response);
            $this->setPagevar('ismobile','false');   
        return 'home';
    }
    public function homep($data=null,$view='homep'){
        App::setSessionVar('homep',true);
        if(App::isMobile()){
            $playlists = $this->getFiles($this->pls);
            $this->setPagevar('playlistcount',count($playlists));
            
            $this->addheadfootsrc(false,array('mobile'=>App::getConfig('appviews').'/styles/mobile.css'));
            $this->setPagevar('ismobile','true');
             
            $view="homep";
        }
        else{
            $this->setPagevar('ismobile','false');   
        }
		return $view;
    }
    public function pageInit($data=null,$view='home'){
        App::setSessionVar('homep',false);
        if(!App::isMobile()){
            $itemtype = $this->paths;
            $this->setPagevar('ajax',false);
            
            unset($itemtype['p']);
            if(isset($data['type'])){
                $this->setPagevar('ajax',true);
                $paths = array($data['type']=>$this->paths[$data['type']]);
            }
            elseif(isset($data['default'])){
                $data['type'] = $data['default'];
                $paths = array($data['type']=>$this->paths[$data['type']]);
            }
            else{
                $data['type'] = 'concert';
                $paths = array('concert'=>$this->paths['concert']);
            }
            
            foreach($paths as $k=>$v){
                $files = $this->getFiles($v);
                $files = $this->controller('sortfile')->pageInit($files);
            }
            
            if(!$this->pagevar['ajax']){
                foreach($itemtype as $k=>$v){
                    $itemtype[$k] = [];
                    $itemtype[$k]['default'] = $k == $data['type'] ? 'active' : '';
                }   
                $this->setPagevar('itemtype',$itemtype);
                $this->setPagevar('files',$files);
                $this->setPagevar('filescount',count($files));
                $playlists = $this->getFiles($this->pls);
                $this->setPagevar('playlistcount',count($playlists));
                
            }
            else{
                $response['filescount'] = count($files);
                
                $this->setPagevar('response',$response);
                $this->setPagevar('files',$files);
                $view = 'browsefile';
            }
            $this->setPagevar('ismobile','false');
        }
        else{
            $playlists = $this->getFiles($this->pls);
            $this->setPagevar('playlistcount',count($playlists));
            $this->setPagevar('ismobile','true');
            $view="mobilehome";
        }
		return $view;
    }
    public function getFiles($path,$files=array()){
        $fileidx    = count($files);
        $filehandle = opendir($path);
		while(false !== ($file = readdir($filehandle))){
			if($file != '.' && $file != '..' ){
			    if(!is_dir($path.'/'.$file)){
			        if($path == App::getConfig('uploads')){
			            if(strpos($file,'xvxv') !== false){
    			            if(!App::getSessionVar('homep'))
    			                continue;
    			        }
    			        else{
    			            if(App::getSessionVar('homep')){
    			                continue;
    			            }
    			        }   
			        }
			        $namex = explode('.',$file);
			        if($path != $this->pls && !in_array(strtolower($namex[count($namex)-1]),$this->unsets)){
			            continue;
			        }
			        unset($namex[count($namex)-1]);
			        $nicename =  implode('.',$namex);
			        
			        if($nicename != ''){
			            $fileidx = count($files);
    			        $files[$fileidx]['nicename'] = $nicename;
    			        
    			        $files[$fileidx]['path'] = $path.'/'.$file;
    			        $files[$fileidx]['name'] = $file;
			        }
			    }
			    else{
			        $files = $this->getFiles($path.'/'.$file,$files);
			    }
			}
		}
		return $files;
    }
}